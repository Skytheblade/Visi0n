﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using DAL;
using ViewModel;

namespace WCFHostConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ServiceHost service = new ServiceHost(typeof(WCFWeBService.ProjectService));

            Console.WriteLine("Starting service:" );

            foreach (var item in service.Description.Endpoints)
            {
                Console.WriteLine(item.Address);
            }
            service.Open();
            Console.ReadLine();
        }
    }
}
