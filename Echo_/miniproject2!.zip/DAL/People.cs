﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class People : BaseEntity
    {
        private string firstName;
        private string lastName;
        private City city;
        private string telephone;

        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public City City { get => city; set => city = value; }
        public string Telephone { get => telephone; set => telephone = value; }
    }
}
