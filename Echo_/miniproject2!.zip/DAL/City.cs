﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class City : BaseEntity
    {
        private string cityName;

        public string Name { get => cityName; set => cityName = value; }
    }
}
