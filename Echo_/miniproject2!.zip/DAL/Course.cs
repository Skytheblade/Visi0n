﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class Course : BaseEntity
    {
        private string subject;

        public string Subject { get => subject; set => subject = value; }
    }
}
