﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ServiceModel;
using DAL;

namespace WCFWeBService
{

    [ServiceContract]
    public interface IProjectService
    {
        [OperationContract]
        StudentList GetAllStudents();

        [OperationContract]
        Student Login(string username, string password);
    }
}
