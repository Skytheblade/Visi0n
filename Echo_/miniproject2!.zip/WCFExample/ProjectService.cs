﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModel;

namespace WCFWeBService
{
    public class ProjectService : IProjectService
    {
        public StudentList GetAllStudents()
        {
            StudentDB studentDB = new StudentDB();

            return studentDB.SelectAll();
        }

        public Student Login(string username, string password)
        {
            StudentDB studentDB = new StudentDB();

            Student user = studentDB.Login(username, password) as Student;

            return user;
        }
    }
}
