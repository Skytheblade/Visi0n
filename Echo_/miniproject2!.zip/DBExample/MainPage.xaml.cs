﻿using DAL;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ViewModel;

namespace DBExample
{
    /// <summary>
    /// Interaction logic for MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        Student student;

        bool removeFromJournal = false;

        public bool RemoveFromJournal
        {
            get { return removeFromJournal; }
            set { removeFromJournal = value; }
        }

        public MainPage()
        {
            InitializeComponent();

            btnFetch_Click(null,null);
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (this.RemoveFromJournal)
            {
                NavigationService nav = NavigationService.GetNavigationService(this);
                nav.RemoveBackEntry();
            }
        }

        private void btnFetch_Click(object sender, RoutedEventArgs e)
        {
            StudentDB db = new StudentDB();
            StudentList list = db.SelectAll();

            txtInfo.Text = "List of Students";

            lvStudentList.ItemsSource = list;
        }

        private void MenuItem_Teachers(object sender, RoutedEventArgs e)
        {
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new TeachersPage(student));
        }        
        
        private void MenuItem_Courses(object sender, RoutedEventArgs e)
        {

        }

        private void lvStudentList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            this.student = lvStudentList.SelectedItem as Student;
        }
    }

}
