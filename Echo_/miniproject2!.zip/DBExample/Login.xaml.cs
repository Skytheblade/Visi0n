﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ViewModel;

namespace DBExample
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Page
    {
        public Login()
        {
            InitializeComponent();

            //MainWindow.User
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            People user;
            if (cmbLoginType.SelectedValue.ToString() == "Student")
            {
                StudentDB studentDB = new StudentDB();
                
                user = studentDB.Login(txtUsername.Text, txtPassword.Text);

                if (user == null)
                    MessageBox.Show("Wrong username or password");
            }
            else
            {
                TeacherDB teacherDB = new TeacherDB();

                user = teacherDB.Login(txtUsername.Text, txtPassword.Text);

                if (user == null)
                    MessageBox.Show("Wrong username or password");
            }

            if (user != null)
            {
                MainWindow.User = user;
                MainWindow.frame.Navigate(new MainPage() { RemoveFromJournal = true });
            }
        }
    }
}
