﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ViewModel;

namespace DBExample
{
    /// <summary>
    /// Interaction logic for TeachersPage.xaml
    /// </summary>
    public partial class TeachersPage : Page
    {
        Student student;
        public TeachersPage(Student student)
        {
            InitializeComponent();

            this.student = student;

            btnFetch_Click(null, null);
        }

        private void btnFetch_Click(object sender, RoutedEventArgs e)
        {
            TeacherDB db = new TeacherDB();
            TeacherList list = db.SelectByStudent(this.student);

            txtInfo.Text = "List of Teachers for : " + student.FirstName + " " + student.LastName;

            lvStudentList.ItemsSource = list;
        }

        private void lvStudentList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            this.student = lvStudentList.SelectedItem as Student;
        }
    }
}
