﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ViewModel;

namespace DBExample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, ICommand
    {
        private static People user;

        public static People User
        {
            get { return user; }
            set { user = value; }
        }

        public static Frame frame;

        public event EventHandler CanExecuteChanged;


        public MainWindow()
        {
            InitializeComponent();

            MainWindow.frame = this.myFrame;

            if (MainWindow.User != null)
            {
                hamburgerMenu.Visibility = Visibility.Visible;
            }
            else
            {
                hamburgerMenu.Visibility = Visibility.Hidden;
            }
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            
        }

        private void HamburgerMenuItem_ListOfStudents_Selected(object sender, RoutedEventArgs e)
        {
            this.myFrame.Navigate(new MainPage());
        }

        private void myFrame_Navigating(object sender, NavigatingCancelEventArgs e)
        {
            if (frame != null && frame.Content != null && // if Self-Navigation
                 frame.Content.GetType() == e.Content.GetType())
            {
                e.Cancel = true;   //cancal navigation
            }

            Dummy.Visibility = Visibility.Visible;
            Dummy.IsSelected = true;
            Dummy.Visibility = Visibility.Collapsed;
        }

        private void myFrame_Navigated(object sender, NavigationEventArgs e)
        {
            if (MainWindow.User != null)
            {
                hamburgerMenu.Visibility = Visibility.Visible;
            }
            else
            {
                hamburgerMenu.Visibility = Visibility.Hidden;
            }
        }

        private void HamburgerMenuItem_AddNewStudent_Selected(object sender, RoutedEventArgs e)
        {
            this.myFrame.Navigate(new AddNewStudent());
        }
    }
}
