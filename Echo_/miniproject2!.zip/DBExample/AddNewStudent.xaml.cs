﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ViewModel;

namespace DBExample
{
    /// <summary>
    /// Interaction logic for AddNewStudent.xaml
    /// </summary>
    public partial class AddNewStudent : Page
    {
        Student student;

        public AddNewStudent()
        {
            InitializeComponent();

            CityDB cityDB = new CityDB();
            cmbCities.ItemsSource = cityDB.SelectAll();
            cmbCities.DisplayMemberPath = "Name";            

        }

        private void btnAddStudent_Click(object sender, RoutedEventArgs e)
        {
            student = new Student();
            student.FirstName = txtFirstname.Text;
            student.LastName = txtLastname.Text;
            student.City = cmbCities.SelectedValue as City;
            student.Telephone = txtPhone.Text;

            StudentDB db = new StudentDB();
            db.Insert(student);
            db.SaveChanges();
        }
    }
}
