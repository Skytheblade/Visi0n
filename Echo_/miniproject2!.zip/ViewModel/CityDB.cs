﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModel
{
    public class CityDB : BaseDB
    {
        // static list to reduce the amount of queries
        private static CityList list = null;

        protected override void CreateModel(BaseEntity entity)
        {
            City city = entity as City;

            city.Id = (int)this.reader["ID"];
            city.Name = this.reader["CityName"].ToString();
        }

        protected override BaseEntity NewEntity()
        {
            return new City();
        }

        // select all using base db
        public CityList SelectAll()
        {
            this.command.CommandText = "Select * from tblCity";
            return new CityList(base.Select());
        }

        public static City SelectById(int cityid)
        {
            if (list == null)
            {
                CityDB db = new CityDB();
                list = db.SelectAll();
            }

            City city = list.Find(item => item.Id == cityid);

            return city;
        }

        public override string CreateInsertSQL(BaseEntity entity)
        {
            throw new NotImplementedException();
        }

        public override string CreateUpdateSQL(BaseEntity entity)
        {
            throw new NotImplementedException();
        }

        public override string CreateDeleteSQL(BaseEntity entity)
        {
            throw new NotImplementedException();
        }
    }
}
