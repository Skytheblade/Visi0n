﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModel
{
    public abstract class PeopleDB : BaseDB
    {

        protected override void CreateModel(BaseEntity entity)
        {
            People people = entity as People;

            people.Id = (int)this.reader["ID"];
            people.FirstName = this.reader["FirstName"].ToString();
            people.LastName = this.reader["LastName"].ToString();
            people.Telephone = this.reader["Telephone"].ToString();

            int cityid = (int)this.reader["City"];
            people.City = CityDB.SelectById(cityid);            
        }

        public override string CreateInsertSQL(BaseEntity entity)
        {
            People person = entity as People;
            string sqlStr = "INSERT INTO tblPeople (Firstname, Lastname, City, Telephone) VALUES " +
                $"('{person.FirstName}','{person.LastName}','{person.City.Id}','{person.Telephone}')";

            return sqlStr;
        }

        public abstract People Login(string username, string password);
    }
}
