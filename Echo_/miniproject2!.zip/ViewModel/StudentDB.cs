﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace ViewModel
{
    public class StudentDB : PeopleDB
    {
        //private string connectionString= "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=E:\\Study\\WPF\\DBExample\\ViewModel\\Database\\mydb.accdb;Persist Security Info=True";
        //protected OleDbConnection connection;
        //protected OleDbCommand command;
        //protected OleDbDataReader reader;

        protected override BaseEntity NewEntity()
        {
            return new Student();
        }

        public StudentList SelectAll()
        {
            this.command.CommandText = "SELECT *, tblPeople.id AS ID FROM (tblPeople INNER JOIN tblStudent ON tblPeople.id = tblStudent.id)";

            return new StudentList(base.Select());
        }

        public StudentList SelectByName(string firstName,string lastName)
        {
            this.command.CommandText = $"SELECT *, tblPeople.id AS ID FROM (tblPeople INNER JOIN tblStudent ON tblPeople.id = tblStudent.id) where Firstname='{firstName}' AND Lastname='{lastName}'";

            return new StudentList(base.Select());
        }

        public StudentList SelectById(int id)
        {
            this.command.CommandText = $"SELECT *, tblPeople.id AS ID FROM (tblPeople INNER JOIN tblStudent ON tblPeople.id = tblStudent.id) where tblPeople.id='{id}'";

            return new StudentList(base.Select());
        }

        //public StudentList Select()
        //{
        //    //this.command.CommandText = "SELECT *, tblPeople.id AS ID FROM (tblPeople INNER JOIN tblStudent ON tblPeople.id = tblStudent.id)";
        //    StudentList list = new StudentList();

        //    try
        //    {
        //        this.command.Connection = connection;
        //        this.connection.Open();

        //        this.reader = command.ExecuteReader();

        //        Student student;

        //        while (this.reader.Read())
        //        {
        //            student = new Student();
        //            CreateModel(student);

        //            list.Add(student);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        System.Diagnostics.Debug.WriteLine(ex.Message + "\nSQL: " + command.CommandText);
        //    }
        //    finally
        //    {
        //        if (this.reader != null)
        //            this.reader.Close();

        //        if (this.connection.State == ConnectionState.Open)
        //            this.connection.Close();
        //    }

        //    return list;

        //}

        private void CreateModel(Student student)
        {
            //student.Id = (int)this.reader["ID"];
            //student.FirstName = this.reader["FirstName"].ToString();
            //student.LastName = this.reader["LastName"].ToString();
            //student.Telephone = this.reader["Telephone"].ToString();
            // TBA : City
            base.CreateModel(student);

            // add properties relevant to student
        }

        public override People Login(string username, string password)
        {
            this.command.CommandText = $"SELECT *, tblPeople.id AS ID FROM (tblPeople INNER JOIN tblStudent ON tblPeople.id = tblStudent.id) where tblPeople.Username='{username}' AND tblPeople.Password='{password}'";

            StudentList lst =new StudentList(base.Select());

            if (lst.Count > 0)
                return lst[0];

            return null;
        }


        #region Insert,Update,Delete

        // this case require multiple inputs
        // so we need to override the insert method
        public override void Insert(BaseEntity entity)
        {
            Student student = entity as Student;

            if (student != null)
            {
                this.inserted.Add(new ChangeEntity(base.CreateInsertSQL, entity));
                this.inserted.Add(new ChangeEntity(this.CreateInsertSQL, entity));
            }
        }

        public override string CreateInsertSQL(BaseEntity entity)
        {
            Student student = entity as Student;

            string sqlStr = $"INSERT INTO tblStudent (id) VALUES ('{student.Id}')";                

            return sqlStr;
        }

        public override string CreateUpdateSQL(BaseEntity entity)
        {
            Student student = entity as Student;
            string sqlStr = $"UPDATE tblPeople SET Firstname = '{student.FirstName}', Lastname ='{student.LastName}', City ='{student.City.Id}', Telephone ='{student.Telephone}' WHERE ID={student.Id}";
                
            return sqlStr;
        }

        public override string CreateDeleteSQL(BaseEntity entity)
        {
            Student student = entity as Student;
            string sqlStr = $"Delete from tblStudent WHERE ID={student.Id}";

            return sqlStr;
        }
        #endregion
    }
}
